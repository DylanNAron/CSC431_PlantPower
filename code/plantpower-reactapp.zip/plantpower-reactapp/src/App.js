import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import Logo from "./plantgraph.png";

export default function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/plantprofile">PlantProfile</Link>
            </li>
           
          </ul>
        </nav>

        {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
        <Switch>
          <Route path="/plantprofile">
            <About />
          </Route>
          <Route path="/users">
            <Users />
          </Route>
          <Route path="/">
            <Home />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

function Home() {
  return (
    <div>
      <h1>Welcome To PlantPower</h1>
      <h2>Plant Power is designed to allow for automation of growing plants through an arduino to a machine learning backend and then to a beautiful webpage. The objective of this project is to create a system for data visualization of plant conditions, which can then be used to predict optimal conditions. The main concept is that the plant, grown hydroponically, will have sensors attached to it that will be collecting data and log them onto a database. These conditions will then be extracted from the database and displayed on a user-friendly interface through a web application built on React.</h2>;
    </div>
  );
}

function About() {
  return(
  <div>
      <h2>Graph generated from your plant's conditions</h2>
      <img src={Logo} alt="plantstats" />
  </div> 
  );
}

function Users() {
  return <h2>Users</h2>;
}